DarkRP.declareChatCommand{
    command = "forcecancelvote",
    description = "Forcefully cancel a vote.",
    delay = 0.5
}
